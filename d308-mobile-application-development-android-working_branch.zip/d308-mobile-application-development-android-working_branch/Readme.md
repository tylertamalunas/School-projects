# Vacation Planner App

## Git repository Link
https://gitlab.com/wgu-gitlab-environment/student-repos/ttamaluD197/d308-mobile-application-development-android/-/tree/working_branch?ref_type=heads

---

## Android Version for APK
Android Version: 8.0.0 (API Level 26)

--- 

## Purpose
The **Vacation Planner App** is an Android application designed to help users plan and manage vacations and excursions efficiently. Users can create, update, and delete vacations, add excursions to each vacation, and set alerts for important excursion or vacation dates.

---

## How to Use
1. Select "Enter" button on Main Activity page. 
2. Select FAB on bottom right to Create a new Vacation. 
3. Enter all vacation details, then click the 3 dots in upper right corner.
4. Select "Save Vacation" to save the vacation details to the database. 
5. Select the vacation that was just made from the "Vacation List" page.
6. Select 3 dots in upper right and select "Delete Vacation" if you would like to delete a vacation.
7. Select "Save Vacation" to update stored vacation with any changed details.
8. Select "Alert" to have a notification pop up when it is the start date of the vacation.
9. Select "Share Vacation" to send vacation details via clipboard, text, or email.
10. Select the FAB in bottom right to go to "Excursion Details" page. 
11. Enter excursion details, then select which vacation you would like to save the excursion to. 
12. Select the 3 dots in upper right to open the menu. 
13. Select "Save Excursion" to save a new excursion, or update an existing one. 
14. Select "Delete Excursion" to delete an existing excursion. 
15. Select "Alert" to create a notification alert on the day of the excursion. 
16. On the "Vacation Details" page, you are able to select an existing excursion that is linked to an existing vacation, to see the excursion details.
17. At any point in the app, you are able to select the back arrow in the upper left, to go to the previous page. 