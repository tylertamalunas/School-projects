package com.example.d308vacationplanner.UI;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.d308vacationplanner.R;

public class MyReceiver extends BroadcastReceiver {
    private static final String TAG = "MyReceiver";
    private static final String VACATION_CHANNEL_ID = "VACATION_CHANNEL";
    private static final String EXCURSION_CHANNEL_ID = "EXCURSION_CHANNEL";

    @Override
    public void onReceive(Context context, Intent intent) {
        String vacationName = intent.getStringExtra("vacationname");
        String excursionName = intent.getStringExtra("excursionname");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel vacationChannel = new NotificationChannel(
                    VACATION_CHANNEL_ID,
                    "Vacation Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationChannel excursionChannel = new NotificationChannel(
                    EXCURSION_CHANNEL_ID,
                    "Excursion Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(vacationChannel);
            notificationManager.createNotificationChannel(excursionChannel);
        }

        if (vacationName != null) {
            // create a notification for vacation
            Notification notification = new NotificationCompat.Builder(context, "VACATION_CHANNEL")
                    .setContentTitle("Vacation Reminder!")
                    .setContentText("Don't forget about your vacation: " + vacationName)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build();

            // notify the user
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(1, notification);
        } else if (excursionName != null) {
            // create a notification for excursion
            Notification notification = new NotificationCompat.Builder(context, "EXCURSION_CHANNEL")
                    .setContentTitle("Excursion Reminder!")
                    .setContentText("Don't forget about your excursion: " + excursionName)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build();

            // notify the user
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(2, notification);
        } else {
            Log.e(TAG, "Both vacation and excursion names are null.");
        }
    }
}