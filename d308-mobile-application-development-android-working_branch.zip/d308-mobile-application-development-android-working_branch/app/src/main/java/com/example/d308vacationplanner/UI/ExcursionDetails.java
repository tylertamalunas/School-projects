package com.example.d308vacationplanner.UI;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.d308vacationplanner.R;
import com.example.d308vacationplanner.database.Repository;
import com.example.d308vacationplanner.entities.Excursion;
import com.example.d308vacationplanner.entities.Vacation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ExcursionDetails extends AppCompatActivity {
    String name;
    String date;
    int excursionID;
    int vacationID;
    EditText editName;
    TextView editDate;
    Excursion currentExcursion;
    Repository repository;
    DatePickerDialog.OnDateSetListener startDate;
    final Calendar myCalendarStart = Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_excursion_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        repository = new Repository(getApplication());
        editName = findViewById(R.id.excursionname);
        editDate = findViewById(R.id.excursiondate);
        excursionID = getIntent().getIntExtra("id", -1);
        vacationID = getIntent().getIntExtra("vacid", -1);
        name = getIntent().getStringExtra("name");
        date = getIntent().getStringExtra("date");
        editName.setText(name);
        editDate.setText(date);

        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        Spinner spinner = findViewById(R.id.spinner);
        ArrayList<Vacation> vacationArrayList = new ArrayList<>();
        vacationArrayList.addAll(repository.getmAllVacations());
        ArrayAdapter<Vacation> vacationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, vacationArrayList);
        spinner.setAdapter(vacationAdapter);

        // spinner stuff
        for (int i = 0; i < vacationArrayList.size(); i++) {
            if (vacationArrayList.get(i).getVacationID() == vacationID) {
                spinner.setSelection(i);
                break;
            }
        }


        startDate = (view, year, month, dayOfMonth) -> {
            myCalendarStart.set(Calendar.YEAR, year);
            myCalendarStart.set(Calendar.MONTH, month);
            myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabelStart();
        };

        editDate.setOnClickListener(v -> {
            String info = editDate.getText().toString();
            if (info.isEmpty()) info = sdf.format(new Date());
            try {
                myCalendarStart.setTime(sdf.parse(info));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            new DatePickerDialog(ExcursionDetails.this, startDate, myCalendarStart.get(Calendar.YEAR),
                    myCalendarStart.get(Calendar.MONTH), myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Excursion Notifications";
            String description = "Notifications for excursion alerts";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("EXCURSION_CHANNEL", name, importance);
            channel.setDescription(description);

            // register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

    }


    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editDate.setText(sdf.format(myCalendarStart.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_excursiondetails, menu);
        return true;
    }

    @SuppressLint("ScheduleExactAlarm")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            onBackPressed();  // handle the back button press. Deprecated, but couldnt figure how else to get it to work.
            return true;
        }
        if (item.getItemId() == R.id.excursionsave) {
            // check if there are no vacations in the database and prevent saving if there arent any.
            if (repository.getmAllVacations().isEmpty()) {
                Toast.makeText(ExcursionDetails.this, "No vacations available. Please create a vacation first.", Toast.LENGTH_LONG).show();
                return false;
            }

            Excursion excursion;
            Spinner spinner = findViewById(R.id.spinner);
            Vacation selectedVacation = (Vacation) spinner.getSelectedItem();
            int selectedVacationID = selectedVacation.getVacationID();

            // check if excursion date is within vacation date range
            String excursionDate = editDate.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
            Date excursionParsedDate = null;
            try {
                excursionParsedDate = sdf.parse(excursionDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (excursionParsedDate != null) {
                // parse the vacation start and end dates from String to Date
                String vacationStartDateStr = selectedVacation.getStartDate();
                String vacationEndDateStr = selectedVacation.getEndDate();

                Date vacationStartDate = null;
                Date vacationEndDate = null;

                try {
                    vacationStartDate = sdf.parse(vacationStartDateStr);
                    vacationEndDate = sdf.parse(vacationEndDateStr);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                // check if vacation date parsing was successful and if excursion date is within range
                if (vacationStartDate != null && vacationEndDate != null) {
                    if (excursionParsedDate.before(vacationStartDate) || excursionParsedDate.after(vacationEndDate)) {
                        Toast.makeText(ExcursionDetails.this, "Excursion date must be within the vacation's date range.", Toast.LENGTH_LONG).show();
                        return false; // prevent saving the excursion if the date parsing failed
                    }
                } else {
                    Toast.makeText(ExcursionDetails.this, "Vacation start or end date is invalid.", Toast.LENGTH_LONG).show();
                    return false; // prevent saving the excursion if date parsing failed
                }
            }

            if (excursionID == -1) {
                if (repository.getmAllExcursions().isEmpty() || repository.getmAllExcursions() == null) {
                    excursionID = 1;
                } else {
                    excursionID = repository.getmAllExcursions().get(repository.getmAllExcursions().size() - 1).getExcursionID() + 1;
                }
                excursion = new Excursion(excursionID, editName.getText().toString(), editDate.getText().toString(), selectedVacationID); // replace?
                repository.insert(excursion);
            } else {
                excursion = new Excursion(excursionID, editName.getText().toString(), editDate.getText().toString(), selectedVacationID); // replace?
                repository.update(excursion);
            }
            this.finish();
        }
        if (item.getItemId() == R.id.excursiondelete) {
            for (Excursion excur : repository.getmAllExcursions()) {
                if (excur.getExcursionID() == excursionID) currentExcursion = excur;
            }
            repository.delete(currentExcursion);
            Toast.makeText(ExcursionDetails.this, currentExcursion.getExcursionName() + "was deleted.", Toast.LENGTH_SHORT).show();
            ExcursionDetails.this.finish();
        }
        if (item.getItemId() == R.id.excursionalert) {
            String excursionDateString = editDate.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
            Date excursionDate = null;

            try {
                excursionDate = sdf.parse(excursionDateString);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (excursionDate != null) {
                setAlarmForExcursion(excursionDate);

                // create an intent to trigger the receiver and send excursion name
                Intent intent = new Intent(ExcursionDetails.this, MyReceiver.class);
                String excursionName = editName.getText().toString();
                intent.putExtra("excursionname", editName.getText().toString());

                PendingIntent sender = PendingIntent.getBroadcast(
                        ExcursionDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, excursionDate.getTime(), sender);

                Toast.makeText(ExcursionDetails.this, "Excursion alert set!", Toast.LENGTH_SHORT).show();
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setAlarmForExcursion(Date excursionDate) {
        long trigger = excursionDate.getTime();

        Intent intent = new Intent(ExcursionDetails.this, MyReceiver.class);
        intent.putExtra("key", "excursion");

        PendingIntent sender = PendingIntent.getBroadcast(ExcursionDetails.this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
    }
    // no onResume as there is no page after this.
}

// commit with section C, B5