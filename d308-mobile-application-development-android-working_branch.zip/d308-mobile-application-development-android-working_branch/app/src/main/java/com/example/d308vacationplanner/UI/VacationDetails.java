package com.example.d308vacationplanner.UI;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d308vacationplanner.R;
import com.example.d308vacationplanner.database.Repository;
import com.example.d308vacationplanner.entities.Excursion;
import com.example.d308vacationplanner.entities.Vacation;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class VacationDetails extends AppCompatActivity {
    String name;
    String hotel;
    String startDate;
    String endDate;
    int vacationID;
    int excursionID;
    EditText editName;
    EditText editHotel;
    TextView editStartDate;
    TextView editEndDate;
    Vacation currentVacation;
    int numExcursions;
    Repository repository;
    DatePickerDialog.OnDateSetListener vacationStartDate;
    DatePickerDialog.OnDateSetListener vacationEndDate;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vacation_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        FloatingActionButton fab = findViewById(R.id.floatingActionButton2);

        repository = new Repository(getApplication());
        editName = findViewById(R.id.vacationname);
        editHotel = findViewById(R.id.hotelname);
        editStartDate = findViewById(R.id.startdate);
        editEndDate = findViewById(R.id.enddate);

        vacationID = getIntent().getIntExtra("id", -1); // check this number
        excursionID = getIntent().getIntExtra("excid", -1); // check number?
        name = getIntent().getStringExtra("name");
        hotel = getIntent().getStringExtra("hotel");
        startDate = getIntent().getStringExtra("startdate");
        endDate = getIntent().getStringExtra("enddate");

        editName.setText(name);
        editHotel.setText(hotel);
        editStartDate.setText(startDate);
        editEndDate.setText(endDate);

        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);


        vacationStartDate = (view, year, month, dayOfMonth) -> {
            myCalendarStart.set(Calendar.YEAR, year);
            myCalendarStart.set(Calendar.MONTH, month);
            myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel(editStartDate, myCalendarStart);
        };

        vacationEndDate = (view, year, month, dayOfMonth) -> {
            myCalendarEnd.set(Calendar.YEAR, year);
            myCalendarEnd.set(Calendar.MONTH, month);
            myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            if (myCalendarEnd.before(myCalendarStart)) {
                Toast.makeText(VacationDetails.this, "End date cannot be before start date!", Toast.LENGTH_LONG).show();
                myCalendarEnd.setTime(myCalendarStart.getTime()); // reset end date to start date
            }
            updateLabel(editEndDate, myCalendarEnd);
        };

        editStartDate.setOnClickListener(v -> {
            String info = editStartDate.getText().toString();
            if (info.isEmpty()) info = sdf.format(new Date());
            try {
                myCalendarStart.setTime(sdf.parse(info));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            new DatePickerDialog(VacationDetails.this, vacationStartDate, myCalendarStart.get(Calendar.YEAR),
                    myCalendarStart.get(Calendar.MONTH), myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
        });

        // changed to lambda
        editEndDate.setOnClickListener(v -> {
            String info = editEndDate.getText().toString();
            if (info.isEmpty()) info = sdf.format(new Date());
            try {
                myCalendarEnd.setTime(sdf.parse(info));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            new DatePickerDialog(VacationDetails.this, vacationEndDate, myCalendarEnd.get(Calendar.YEAR),
                    myCalendarEnd.get(Calendar.MONTH), myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
        });

        // made into lambda
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(VacationDetails.this, ExcursionDetails.class);
            // pass vacation detials to excursiondetials page
            intent.putExtra("vacid", vacationID);
            intent.putExtra("name", editName.getText().toString());
            intent.putExtra("hotel", editHotel.getText().toString());
            intent.putExtra("start date", editStartDate.getText().toString());
            intent.putExtra("end date", editEndDate.getText().toString());
            startActivity(intent);
        });
    }


    private void updateLabel(TextView targetView, Calendar calendar) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        String formattedDate = sdf.format(calendar.getTime());

        targetView.setText(sdf.format(calendar.getTime()));

        if (targetView == editStartDate) {
            startDate = formattedDate;
        } else if (targetView == editEndDate) {
            endDate = formattedDate;
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacationdetails, menu);
        return true;
    }

    @SuppressLint("ScheduleExactAlarm")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();  // handle the back button press. Deprecated, but couldnt figure how else to get it to work.
            return true;
        }
        if (item.getItemId() == R.id.vacationsave) {
            if (myCalendarEnd.before(myCalendarStart)) {
                Toast.makeText(this, "Invalid dates: End date must be after start date!", Toast.LENGTH_LONG).show();
                return false; // prevent saving the vacation if date parsing failed
            }
            Vacation vacation;
            if (vacationID == -1) {
                if (repository.getmAllVacations().isEmpty()) vacationID = 1;
                else
                    vacationID = repository.getmAllVacations().get(repository.getmAllVacations().size() - 1).getVacationID() + 1;
                vacation = new Vacation(vacationID, editName.getText().toString(), editHotel.getText().toString(), editStartDate.getText().toString(), editEndDate.getText().toString(), excursionID);
                repository.insert(vacation);
            } else {
                vacation = new Vacation(vacationID, editName.getText().toString(), editHotel.getText().toString(), editStartDate.getText().toString(), editEndDate.getText().toString(), excursionID);
                repository.update(vacation);
            }
            finish();
            return true;
        }
        if (item.getItemId() == R.id.vacationshare) {
            String vacationName = editName.getText().toString();
            String vacationDetails = "Here are the details for my " + vacationName + " vacation.\n\n" +
                    "Hotel: " + editHotel.getText().toString() + "\n" +
                    "Start Date: " + startDate + "\n" +
                    "End Date: " + endDate;

            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, vacationDetails);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, vacationName + " Vacation Details");
            sendIntent.setType("text/plain");

            Intent shareIntent = Intent.createChooser(sendIntent, "Share Vacation Details");
            startActivity(shareIntent);
        }

        if (item.getItemId() == R.id.vacationdelete) {
            for (Vacation vacay : repository.getmAllVacations()) {
                if (vacay.getVacationID() == vacationID) currentVacation = vacay;
            }
            numExcursions = 0;
            for (Excursion excur : repository.getmAllExcursions()) {
                if (excur.getVacationID() == vacationID) ++numExcursions;
            }
            if (numExcursions == 0) {
                repository.delete(currentVacation);
                Toast.makeText(VacationDetails.this, currentVacation.getVacationName() + "was deleted.", Toast.LENGTH_SHORT).show();
                VacationDetails.this.finish();
            } else {
                Toast.makeText(VacationDetails.this, "Can't delete a vacation with excursions!", Toast.LENGTH_LONG).show();
            }
        }
        if (item.getItemId() == R.id.vacationalert) {
            String vacationDateString = editStartDate.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy", Locale.US);
            Date vacationDate = null;

            try {
                vacationDate = sdf.parse(vacationDateString);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (vacationDate != null) {
                setAlarmForVacation(vacationDate);

                // create an intent to trigger the receiver and send vacation name
                Intent intent = new Intent(VacationDetails.this, MyReceiver.class);
                String vacationName = editName.getText().toString();
                intent.putExtra("vacationname", editName.getText().toString());

                PendingIntent sender = PendingIntent.getBroadcast(
                        VacationDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);

                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, vacationDate.getTime(), sender);

                Toast.makeText(VacationDetails.this, "Vacation alert set!", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setAlarmForVacation(Date vacationDate) {
        long trigger = vacationDate.getTime();

        Intent intent = new Intent(VacationDetails.this, MyReceiver.class);
        intent.putExtra("key", "vacationname");

        PendingIntent sender = PendingIntent.getBroadcast(VacationDetails.this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
    }

    @Override
    protected void onResume() {
        super.onResume();
        RecyclerView recyclerView = findViewById(R.id.vacationrecyclerviewdetails);
        repository = new Repository((getApplication()));
        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        excursionAdapter.setExcursions(repository.getmAllExcursions());
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion ex : repository.getmAllExcursions()) {
            if (ex.getVacationID() == vacationID) filteredExcursions.add(ex);
        }
        excursionAdapter.setExcursions(filteredExcursions);
    }
}

// commit with section C, B3