package com.example.demo.services;

public interface Checkout {

    PurchaseResponse placeOrder(Purchase purchase);
}
