package com.example.demo.bootstrap;

import com.example.demo.dao.CustomerRepository;
import com.example.demo.dao.DivisionRepository;
import com.example.demo.entities.Customer;
import com.example.demo.entities.Division;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {

    private final CustomerRepository customerRepository;
    private final DivisionRepository divisionRepository;

    public BootStrapData(CustomerRepository customerRepository, DivisionRepository divisionRepository) {
        this.customerRepository = customerRepository;
        this.divisionRepository = divisionRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        Division az = new Division();
        az.setId(2L);

        Customer tyler = new Customer();
        tyler.setFirstName("Tyler");
        tyler.setLastName("Tams");
        tyler.setAddress("1234 w lane");
        tyler.setPostal_code("12345");
        tyler.setPhone("1234567890");
        tyler.setDivision(az);
        az.getCustomers().add(tyler);

        Customer jason = new Customer();
        jason.setFirstName("Jason");
        jason.setLastName("Joy");
        jason.setAddress("1234 w Road");
        jason.setPostal_code("125345");
        jason.setPhone("1234567890");
        jason.setDivision(az);
        az.getCustomers().add(jason);

        Customer ginny = new Customer();
        ginny.setFirstName("Ginny");
        ginny.setLastName("Weasley");
        ginny.setAddress("1564 w North");
        ginny.setPostal_code("1253");
        ginny.setPhone("1234567890");
        ginny.setDivision(az);
        az.getCustomers().add(ginny);

        Customer harry = new Customer();
        harry.setFirstName("Harry");
        harry.setLastName("Potter");
        harry.setAddress("154 harvard st");
        harry.setPostal_code("12653");
        harry.setPhone("1234567890");
        harry.setDivision(az);
        az.getCustomers().add(harry);

        Customer hermoine = new Customer();
        hermoine.setFirstName("Hermoine");
        hermoine.setLastName("Granger");
        hermoine.setAddress("14 oakly st");
        hermoine.setPostal_code("85497");
        hermoine.setPhone("1234567890");
        hermoine.setDivision(az);
        az.getCustomers().add(hermoine);

        if (customerRepository.count() <= 1) {
            customerRepository.save(tyler);
            customerRepository.save(jason);
            customerRepository.save(ginny);
            customerRepository.save(harry);
            customerRepository.save(hermoine);
        }

        System.out.println("Started in Bootstrap");
        System.out.println("Number of Customers"+customerRepository.count());
        System.out.println(customerRepository.findAll());

    }
}
